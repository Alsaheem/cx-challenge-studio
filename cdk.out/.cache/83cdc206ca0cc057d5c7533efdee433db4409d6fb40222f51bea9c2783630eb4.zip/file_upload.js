const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  try {
    const bucketName = process.env.BUCKET_NAME;
    const tableName = process.env.TABLE_NAME;

    // Extract file content from the event body
    // console.log(event.body)
    const requestData = JSON.parse(JSON.stringify(event.body));
    console.log(requestData)
    console.log(requestData.username)
    // console.log(fileContent.data)
    // console.log(event.body["username"])
    // console.log(event.body["fileContent"])
    // console.log("uploading content")
    // Upload the file content to S3
    // await s3
    //   .putObject({
    //     Bucket: bucketName,
    //     Key: fileContent.filename,
    //     Body: JSON.stringify(fileContent.data),
    //   })
    //   .promise();
    
    

    // Insert data into DynamoDB
    // await dynamodb
    //   .put({
    //     TableName: tableName,
    //     Item: {
    //       id: fileContent.filename,
    //       data: fileContent.data,
    //     },
    //   })
    //   .promise();

    return {
      statusCode: 200,
      body: JSON.stringify('File uploaded and data inserted into DynamoDB.'),
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify('An error occurred.'),
    };
  }
};
