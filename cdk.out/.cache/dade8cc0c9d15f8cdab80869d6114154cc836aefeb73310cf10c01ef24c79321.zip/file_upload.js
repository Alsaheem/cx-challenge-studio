const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  try {
    const bucketName = process.env.BUCKET_NAME;
    const tableName = process.env.TABLE_NAME;

    // Extract file content from the event body
    const fileContent = JSON.parse(event.body);
    console.log(event.body)
    console.log(fileContent)

    // Upload the file content to S3
    await s3
      .putObject({
        Bucket: bucketName,
        Key: fileContent.filename,
        Body: JSON.stringify(fileContent.data),
      })
      .promise();

    // Insert data into DynamoDB
    // await dynamodb
    //   .put({
    //     TableName: tableName,
    //     Item: {
    //       id: fileContent.filename,
    //       data: fileContent.data,
    //     },
    //   })
    //   .promise();

    return {
      statusCode: 200,
      body: JSON.stringify('File uploaded and data inserted into DynamoDB.'),
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify('An error occurred.'),
    };
  }
};
